# 01 Cover — texts

> Edit text below. After save, run:
>   python3 assets/apply-texts.py <deck.html> <texts.md>
>
> Rules:
>   • Edit ONLY this file. Visual tweaks → overrides.css.
>     Layout / structure / new slides → re-ask Claude.
>   • Use `\n` to insert a line break (renders as <br>).
>   • Do NOT rename the slide-NN.field ids — they pair with HTML.

## slide-01 (cover) — 01 Cover
title: 火山方舟大模型\n数据安全合规
subtitle: 亿滋（Mondelez）客户问答 · 基于官方条款逐条答复
author: 火山引擎 · 东区 SA 团队
date: 2026.06.15

## slide-02 (content-2col) — 02 客户四问 · 逐条答复
title: 客户四问 · 逐条答复
q1.title: 行为及信息审查，如何做到数据0保存？
q1.answer: <span class="a-yes">✅ 自动化过滤审核，非人工审查。</span>审查对象为输入+输出内容，目的为建立风险过滤机制与特征库。\n<span class="a-pending">【待确认】</span>审查后原始数据是否立即删除？特征库是否包含可还原的原始内容？
q2.title: 排障工具中"合理时间"是多长？主动提供的数据范围？
q2.answer: <span class="a-yes">✅ 仅在排障/模型效果咨询时处理，依据用户委托。</span>触发条件为用户使用排障工具或主动提供数据。\n<span class="a-pending">【待确认】</span>"合理时间"具体天数？"主动提供"是否包含正常API调用数据？
q3.title: 异常告警存储和审查的范围、通知机制、解除时间？
q3.answer: <span class="a-yes">✅ 告警解除后不再存储和审查。</span>触发条件为模型异常调用告警，目的为防范安全合规风险。\n<span class="a-pending">【待确认】</span>数据范围、是否通知客户、解除时长与判定机制？
q4.title: 聚合数据的定义、存储时长和分析方式？
q4.answer: <span class="a-yes">✅ 明确不存储和使用任何原始数据。</span>仅对聚合数据进行统计分析，目的为优化平台服务体验。\n<span class="a-pending">【待确认】</span>"聚合数据"具体维度？存储时长？是否涉及第三方？

## slide-03 (content-2col) — 03 Q1 行为及信息审查
title: Q1 · 行为及信息审查，如何做到数据0保存？

## slide-04 (content-2col) — 04 Q2 排障数据存储
title: Q2 · 排障工具中"合理时间"与数据范围

## slide-05 (content-2col) — 05 Q3 异常告警
title: Q3 · 异常告警存储和审查的范围与机制

## slide-06 (content-2col) — 06 Q4 聚合数据
title: Q4 · 聚合数据的定义、存储与分析

## slide-07 (content-2col) — 07 安全能力总览
title: 火山方舟安全能力总览

## slide-08 (content-2col) — 08 延伸问题预判 ①
title: 可能出现的延伸问题（1/2）

## slide-09 (content-2col) — 09 延伸问题预判 ②
title: 可能出现的延伸问题（2/2）

## slide-10 (content-2col) — 10 关键出处
title: 关键出处索引
